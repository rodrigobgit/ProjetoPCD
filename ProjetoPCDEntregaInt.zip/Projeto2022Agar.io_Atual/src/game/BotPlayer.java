package game;

import java.util.function.ToDoubleBiFunction;

import environment.Cell;
import environment.Coordinate;
import environment.Direction;

public class BotPlayer extends Player {
	private long interval = Game.REFRESH_INTERVAL;


	public BotPlayer(Game game, int id, byte originalStrength) {
		super(game, id, originalStrength);

	}
	
	public void run() {
		game.addPlayerToGame(this);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e1) {}

		while (!Thread.interrupted() && this.getCurrentStrength() > 0 && this.getCurrentStrength() < 10) {
			try {
				sleep(interval * getDebuffMultiplier());
				rollDice();
			} catch (InterruptedException e) {
				return;
			}
		}
		
	}
	
	public void rollDice() {
		// Escolha da direção para movimento
		double random=Math.random();
		Direction direction = null;
		
		if (random<0.25) direction=environment.Direction.UP;
		if (random<0.50 && random>=0.25) direction=environment.Direction.DOWN;
		if (random<0.75 && random>=0.5)	direction=environment.Direction.LEFT;
		if (random>=0.75) direction=environment.Direction.RIGHT;
		
		movePlayer(direction, getCurrentCell());
	}
	public void movePlayer(Direction dir,Cell cell) {
		// Calcula coordenada da proxima cell		
		Coordinate atualCoord = cell.getPosition();
		Coordinate nextCoord = atualCoord.translate(dir.getVector());
		// Verifica se está dentro do board		
		if(nextCoord.getX()>=0 && nextCoord.getY()>=0 && nextCoord.getX()<Game.DIMX && nextCoord.getY()<Game.DIMY) {
			Cell nextCell=game.getCell(nextCoord);
			
			//todo o codigo ate ao else rollDice deverá estar no metodo movementPut da classe Cell
			//nextCell.movementPut(this);			
			
			if (nextCell.isOcupied()) { // 
				if(nextCell.getPlayer().getCurrentStrength()> 0) { 
					addStrength(this,nextCell.getPlayer());
					game.notifyChange();
				}
			} else { 
				cell.clear(); 
				nextCell.movementPut(this); 
				setCurrentCell(nextCell); 
				game.notifyChange();
			}
		} else { // Fora dos limites do board
			rollDice(); // É dada outra chance para mover em vez de ficar à espera do REFRESH_INTERVAL
		}
	}
	
	public boolean isHumanPlayer() {
		return false;
	}
}