package game;

import environment.Cell;
import environment.Coordinate;
import environment.Direction;

/**
 * Class to demonstrate a player being added to the game.
 * @author luismota
 *
 */
public class HumanPlayer extends Player {
	private Direction nextDirection;
	private int move;
	private long interval=Game.REFRESH_INTERVAL;
	public HumanPlayer(Game game, int id, byte originalStrength) {
		super(game, id, originalStrength);
	}
	
	public void run() {
		game.addPlayerToGame(this);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e1) {}
		while(!Thread.interrupted() && this.getCurrentStrength() > 0 && this.getCurrentStrength() < 10)
			try {
				sleep(interval*getDebuffMultiplier());
				
				if(move==1) {
					
					movePlayer(nextDirection, getCurrentCell());
				}
				else {
					
				}
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			
	}
	
	
	public void movePlayer(Direction dir,Cell cell) {
		
		//calculo da coordenada da proxima cell	
		Coordinate atual=cell.getPosition();
		Coordinate next=atual.translate(dir.getVector());
	
	
		//verificar se está dentro do board		
		if(next.getX()>=0 && next.getY()>=0 && next.getX()<30 && next.getY()<30) {
			Cell nextCell=game.getCell(next);
			
			//todo o codigo ate ao else rollDice deverá estar no metodo movementPut da classe Cell
			//nextCell.movementPut(this);
			
			//mete a proxima cell a ter este jogador,muda a cell atual do jogador para a próxima e apaga o seu registo na cell de que vai sair
			if (nextCell.isOcupied()) { // Célula ocupada por outro jogar
				if(nextCell.getPlayer().getCurrentStrength()> 0) { // Célula ocupada com jogador vivo
					addStrength(this,nextCell.getPlayer());
					game.notifyChange();
				}
			} else { // Célula não ocupada
				cell.clear(); // Grava null no atributo jogador da célula
				nextCell.movementPut(this); // Grava o jogador em atributo da próxima célula
				setCurrentCell(nextCell); // Grava a próxima célula em atributo do jogador  
				game.notifyChange();
				setMove(0);	
		}
	}
	}
	
	
	public void setNextDirection(Direction direction) {
		this.nextDirection=direction;
		setMove(1);
	}
	public void setMove(int move) {
		this.move = move;
	}
	public int getMove() {
		return move;
	}
	
	
	public boolean isHumanPlayer() {
		return true;
	}
}
